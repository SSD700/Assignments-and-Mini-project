n = int(input("Enter number of subjects: "))
marks = [float(input("Enter marks: ")) for i in range(n)]

avg = sum(marks) / n

if avg >= 90:
    grade = "A"
elif avg >= 75:
    grade = "B"
elif avg >= 60:
    grade = "C"
elif avg >= 40:
    grade = "D"
else:
    grade = "F"

print("Average:", avg)
print("Grade:", grade)