balance = 1000
pin = "1234"

def check_balance():
    print("Balance:", balance)

def deposit():
    global balance
    amount = float(input("Enter deposit amount: "))
    balance += amount
    print("Amount deposited successfully!")

def withdraw():
    global balance
    amount = float(input("Enter withdrawal amount: "))
    if amount <= balance:
        balance -= amount
        print("Withdrawal successful!")
    else:
        print("Insufficient balance!")

if input("Enter PIN: ") == pin:
    while True:
        print("\n1. Check Balance\n2. Deposit\n3. Withdraw\n4. Exit")
        choice = input("Enter choice: ")

        if choice == "1":
            check_balance()
        elif choice == "2":
            deposit()
        elif choice == "3":
            withdraw()
        elif choice == "4":
            print("Thank you for using ATM!")
            break
        else:
            print("Invalid choice!")
else:
    print("Incorrect PIN!")